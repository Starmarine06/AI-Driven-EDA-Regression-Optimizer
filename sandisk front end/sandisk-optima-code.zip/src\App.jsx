import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  Activity, DollarSign, Clock, AlertTriangle,
  Cpu, Layout, TrendingDown, CheckCircle, XCircle, Search,
  PlayCircle, HardDrive, Database, Filter, X, Maximize,
  ChevronDown, ArrowUpDown, ArrowUp, ArrowDown, Zap,
  Shield, BarChart3, Layers, Info, ChevronLeft, ChevronRight,
  Gauge, Timer, MemoryStick, CircuitBoard,
  Bug, GitCommit, FileWarning, Crosshair, Target,
  Lightbulb, FolderSearch, Hash, Flame, Network,
  AlertOctagon, ShieldAlert, Eye, ArrowRight, ChevronUp,
  Fingerprint, Repeat, Scan, Copy, Sparkles, Download
} from 'lucide-react';

// ─────────────────────────────────────────────────
// SANDISK SPECIFIC SYNTHETIC DATA
// ─────────────────────────────────────────────────

const MOCK_COMMITS = [
  { id: 'sd_ftl_9f2a', author: 'jdoe (Junior)', message: 'Update FTL wear-leveling algorithm for QLC NAND', churn: 'High', files: 12, insertions: 847, deletions: 291 },
  { id: 'sd_nvme_4d9', author: 'asmith (Senior)', message: 'Fix NVMe completion queue timeout bug', churn: 'Low', files: 3, insertions: 42, deletions: 18 },
  { id: 'sd_ecc_1b8d', author: 'bjones (Mid)', message: 'Refactor LDPC ECC decoder soft-read logic', churn: 'Medium', files: 7, insertions: 315, deletions: 198 },
];

const BASE_MODULES = [
  { id: 'pcie_mac', name: 'PCIe Gen4 PHY', group: 'Host IO', loc: 18000, fp: { top: '0%', left: '0%', width: '18%', height: '100%' } },
  { id: 'nvme_ctrl', name: 'NVMe Core', group: 'Host Logic', loc: 28000, fp: { top: '0%', left: '20%', width: '28%', height: '38%' } },
  { id: 'aes_crypto', name: 'AES-256 Engine', group: 'Security', loc: 9000, fp: { top: '40%', left: '20%', width: '28%', height: '20%' } },
  { id: 'dram_ctrl', name: 'DRAM Ctrl', group: 'Memory', loc: 12000, fp: { top: '62%', left: '20%', width: '28%', height: '38%' } },
  { id: 'ftl_core', name: 'Flash Translation Layer', group: 'Firmware', loc: 45000, fp: { top: '0%', left: '50%', width: '50%', height: '48%' } },
  { id: 'ecc_ldpc', name: 'LDPC ECC Engine', group: 'Data Integrity', loc: 32000, fp: { top: '50%', left: '50%', width: '50%', height: '30%' } },
  { id: 'nand_onfi', name: 'ONFI NAND PHY', group: 'Storage IO', loc: 15000, fp: { top: '82%', left: '50%', width: '50%', height: '18%' } },
];

const COMMIT_RISK_PROFILES = {
  'sd_ftl_9f2a': { ftl_core: 0.94, nand_onfi: 0.55, dram_ctrl: 0.42 },
  'sd_nvme_4d9': { nvme_ctrl: 0.82, pcie_mac: 0.68, dram_ctrl: 0.15 },
  'sd_ecc_1b8d': { ecc_ldpc: 0.89, ftl_core: 0.35, nand_onfi: 0.45 },
};

// ─────────────────────────────────────────────────
// ERROR CATEGORIES & FAILURE CLUSTERS
// ─────────────────────────────────────────────────

const ERROR_CATEGORIES = [
  { id: 'timeout', label: 'Timeout / Hang', icon: 'Clock', color: '#f59e0b', bgClass: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  { id: 'assertion', label: 'Assertion Failure', icon: 'AlertOctagon', color: '#ef4444', bgClass: 'bg-red-500/10 text-red-400 border-red-500/20' },
  { id: 'protocol', label: 'Protocol Violation', icon: 'ShieldAlert', color: '#a855f7', bgClass: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
  { id: 'data_integrity', label: 'Data Mismatch', icon: 'Database', color: '#3b82f6', bgClass: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
  { id: 'resource', label: 'Resource Exhaustion', icon: 'Flame', color: '#f97316', bgClass: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
];

// Signature generation: deterministic hash from category + signal + module
function generateSignature(category, signal, testId) {
  const mod = testId.split('_').slice(1, -1).join('_');
  const raw = `${category}::${signal}::${mod}`;
  let hash = 0;
  for (let i = 0; i < raw.length; i++) {
    hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
  }
  return 'SIG-' + Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
}

// Per-commit failure cluster data with unique signatures and recurrence tracking
const COMMIT_FAILURE_CLUSTERS = {
  'sd_ftl_9f2a': [
    { id: 'F001', testId: 'TB_FTL_CORE_001', category: 'assertion', severity: 'critical', signal: 'ftl_map_table_update', message: 'L2P mapping corrupted after wear-leveling pass on block 0x3FA2', affectedTests: 8, relatedChange: 'ftl_wl_engine.sv:142 — new block rotation logic', signature: generateSignature('assertion', 'ftl_map_table_update', 'TB_FTL_CORE_001'), recurrences: 5, firstSeen: 'REG-2024-1187', lastSeen: 'REG-2024-1203' },
    { id: 'F002', testId: 'TB_FTL_CORE_003', category: 'data_integrity', severity: 'critical', signal: 'nand_write_verify', message: 'Write-verify mismatch on QLC page 3 after GC compaction', affectedTests: 6, relatedChange: 'ftl_gc_compact.sv:89 — modified page packing order', signature: generateSignature('data_integrity', 'nand_write_verify', 'TB_FTL_CORE_003'), recurrences: 3, firstSeen: 'REG-2024-1195', lastSeen: 'REG-2024-1203' },
    { id: 'F003', testId: 'TB_NAND_ONFI_002', category: 'timeout', severity: 'high', signal: 'onfi_ready_busy_n', message: 'NAND tR timeout exceeded 200µs during multi-plane read', affectedTests: 4, relatedChange: 'ftl_wl_engine.sv:210 — new timing constraint', signature: generateSignature('timeout', 'onfi_ready_busy_n', 'TB_NAND_ONFI_002'), recurrences: 2, firstSeen: 'REG-2024-1200', lastSeen: 'REG-2024-1203' },
    { id: 'F004', testId: 'TB_DRAM_CTRL_001', category: 'resource', severity: 'medium', signal: 'dram_cmd_queue_full', message: 'DRAM command queue overflow under sustained FTL writeback', affectedTests: 3, relatedChange: 'ftl_writeback.sv:55 — increased burst length', signature: generateSignature('resource', 'dram_cmd_queue_full', 'TB_DRAM_CTRL_001'), recurrences: 7, firstSeen: 'REG-2024-1150', lastSeen: 'REG-2024-1203' },
    { id: 'F005', testId: 'TB_FTL_CORE_005', category: 'assertion', severity: 'high', signal: 'ftl_trim_bitmap', message: 'Trim bitmap inconsistency after concurrent UNMAP + write', affectedTests: 5, relatedChange: 'ftl_wl_engine.sv:142 — new block rotation logic', signature: generateSignature('assertion', 'ftl_trim_bitmap', 'TB_FTL_CORE_005'), recurrences: 1, firstSeen: 'REG-2024-1203', lastSeen: 'REG-2024-1203' },
    { id: 'F006', testId: 'TB_NAND_ONFI_004', category: 'protocol', severity: 'low', signal: 'onfi_crc_check', message: 'Optional CRC field not populated on status read', affectedTests: 1, relatedChange: 'nand_onfi_phy.sv:78 — status register mask', signature: generateSignature('protocol', 'onfi_crc_check', 'TB_NAND_ONFI_004'), recurrences: 12, firstSeen: 'REG-2024-1089', lastSeen: 'REG-2024-1203' },
  ],
  'sd_nvme_4d9': [
    { id: 'F007', testId: 'TB_NVME_CTRL_001', category: 'timeout', severity: 'critical', signal: 'cq_doorbell_timeout', message: 'Completion queue doorbell write timed out after 500ms', affectedTests: 7, relatedChange: 'nvme_cq_arbiter.sv:34 — doorbell interrupt path fix', signature: generateSignature('timeout', 'cq_doorbell_timeout', 'TB_NVME_CTRL_001'), recurrences: 4, firstSeen: 'REG-2024-1191', lastSeen: 'REG-2024-1203' },
    { id: 'F008', testId: 'TB_PCIE_MAC_002', category: 'protocol', severity: 'high', signal: 'pcie_tlp_malformed', message: 'Malformed TLP header detected on Gen4 x4 link', affectedTests: 4, relatedChange: 'nvme_cq_arbiter.sv:34 — changed TLP routing', signature: generateSignature('protocol', 'pcie_tlp_malformed', 'TB_PCIE_MAC_002'), recurrences: 1, firstSeen: 'REG-2024-1203', lastSeen: 'REG-2024-1203' },
    { id: 'F009', testId: 'TB_NVME_CTRL_003', category: 'assertion', severity: 'medium', signal: 'nvme_sq_head_ptr', message: 'SQ head pointer wraparound assertion on queue depth 1024', affectedTests: 3, relatedChange: 'nvme_sq_engine.sv:112 — pointer width change', signature: generateSignature('assertion', 'nvme_sq_head_ptr', 'TB_NVME_CTRL_003'), recurrences: 6, firstSeen: 'REG-2024-1165', lastSeen: 'REG-2024-1203' },
    { id: 'F010', testId: 'TB_PCIE_MAC_004', category: 'data_integrity', severity: 'low', signal: 'pcie_ecrc_mismatch', message: 'ECRC mismatch on completion with relaxed ordering', affectedTests: 2, relatedChange: 'pcie_mac_layer.sv:201 — ECRC generation update', signature: generateSignature('data_integrity', 'pcie_ecrc_mismatch', 'TB_PCIE_MAC_004'), recurrences: 9, firstSeen: 'REG-2024-1102', lastSeen: 'REG-2024-1203' },
  ],
  'sd_ecc_1b8d': [
    { id: 'F011', testId: 'TB_ECC_LDPC_001', category: 'assertion', severity: 'critical', signal: 'ldpc_syndrome_zero', message: 'Decoder converged to wrong codeword — syndrome zero but data corrupted', affectedTests: 9, relatedChange: 'ecc_ldpc_decoder.sv:67 — soft-read LLR quantization change', signature: generateSignature('assertion', 'ldpc_syndrome_zero', 'TB_ECC_LDPC_001'), recurrences: 2, firstSeen: 'REG-2024-1199', lastSeen: 'REG-2024-1203' },
    { id: 'F012', testId: 'TB_ECC_LDPC_003', category: 'data_integrity', severity: 'critical', signal: 'ecc_uncorrectable', message: 'Uncorrectable error rate spiked 3× on 3D QLC read-retry path', affectedTests: 7, relatedChange: 'ecc_ldpc_decoder.sv:115 — retry threshold adjustment', signature: generateSignature('data_integrity', 'ecc_uncorrectable', 'TB_ECC_LDPC_003'), recurrences: 3, firstSeen: 'REG-2024-1195', lastSeen: 'REG-2024-1203' },
    { id: 'F013', testId: 'TB_FTL_CORE_002', category: 'timeout', severity: 'high', signal: 'ecc_decode_latency', message: 'ECC decode latency exceeded 40µs SLA for sequential read', affectedTests: 5, relatedChange: 'ecc_ldpc_decoder.sv:67 — iteration count change', signature: generateSignature('timeout', 'ecc_decode_latency', 'TB_FTL_CORE_002'), recurrences: 8, firstSeen: 'REG-2024-1140', lastSeen: 'REG-2024-1203' },
    { id: 'F014', testId: 'TB_NAND_ONFI_001', category: 'protocol', severity: 'medium', signal: 'onfi_read_retry_seq', message: 'Read-retry feature address sequence violated ONFI 4.2 spec', affectedTests: 3, relatedChange: 'nand_read_retry.sv:45 — feature address table update', signature: generateSignature('protocol', 'onfi_read_retry_seq', 'TB_NAND_ONFI_001'), recurrences: 1, firstSeen: 'REG-2024-1203', lastSeen: 'REG-2024-1203' },
    { id: 'F015', testId: 'TB_ECC_LDPC_005', category: 'resource', severity: 'medium', signal: 'ldpc_buffer_overflow', message: 'Decoder input buffer overflow on back-to-back multiplane reads', affectedTests: 4, relatedChange: 'ecc_ldpc_decoder.sv:180 — buffer depth reduction', signature: generateSignature('resource', 'ldpc_buffer_overflow', 'TB_ECC_LDPC_005'), recurrences: 5, firstSeen: 'REG-2024-1178', lastSeen: 'REG-2024-1203' },
  ],
};

// Recent design/testbench changes per commit
const RECENT_CHANGES = {
  'sd_ftl_9f2a': [
    { file: 'ftl_wl_engine.sv', lines: '142-210', type: 'Design', description: 'New block rotation and wear-leveling algorithm for QLC endurance', riskScore: 0.92 },
    { file: 'ftl_gc_compact.sv', lines: '78-95', type: 'Design', description: 'Modified garbage collection page packing for 4-plane QLC', riskScore: 0.78 },
    { file: 'ftl_writeback.sv', lines: '50-62', type: 'Design', description: 'Increased DRAM writeback burst length from 8 to 16', riskScore: 0.45 },
    { file: 'tb_ftl_wl_test.sv', lines: '1-300', type: 'Testbench', description: 'New wear-leveling stress test stimulus', riskScore: 0.30 },
  ],
  'sd_nvme_4d9': [
    { file: 'nvme_cq_arbiter.sv', lines: '28-52', type: 'Design', description: 'Fixed completion queue doorbell interrupt acknowledgement path', riskScore: 0.85 },
    { file: 'nvme_sq_engine.sv', lines: '108-120', type: 'Design', description: 'Changed SQ head pointer register width from 10 to 11 bits', riskScore: 0.60 },
    { file: 'pcie_mac_layer.sv', lines: '195-210', type: 'Design', description: 'Updated ECRC generation for relaxed ordering completions', riskScore: 0.35 },
  ],
  'sd_ecc_1b8d': [
    { file: 'ecc_ldpc_decoder.sv', lines: '60-180', type: 'Design', description: 'Refactored soft-read LLR quantization and iteration control', riskScore: 0.91 },
    { file: 'nand_read_retry.sv', lines: '40-55', type: 'Design', description: 'Updated ONFI 4.2 read-retry feature address sequence', riskScore: 0.55 },
    { file: 'tb_ecc_stress.sv', lines: '1-450', type: 'Testbench', description: 'New multi-corner ECC decode stress patterns', riskScore: 0.25 },
  ],
};

const SEVERITY_ORDER = { critical: 4, high: 3, medium: 2, low: 1 };
const SEVERITY_COLORS = {
  critical: { bg: 'bg-red-500/15', text: 'text-red-400', border: 'border-red-500/30', dot: 'bg-red-500' },
  high:     { bg: 'bg-orange-500/15', text: 'text-orange-400', border: 'border-orange-500/30', dot: 'bg-orange-500' },
  medium:   { bg: 'bg-amber-500/15', text: 'text-amber-400', border: 'border-amber-500/30', dot: 'bg-amber-400' },
  low:      { bg: 'bg-zinc-500/15', text: 'text-zinc-400', border: 'border-zinc-500/30', dot: 'bg-zinc-500' },
};

// Seeded random for deterministic test generation
function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

// ─────────────────────────────────────────────────
// ANIMATED NUMBER HOOK
// ─────────────────────────────────────────────────

function useAnimatedNumber(target, duration = 600) {
  const [value, setValue] = useState(0);
  const frameRef = useRef(null);
  const startRef = useRef(null);
  const fromRef = useRef(0);

  useEffect(() => {
    fromRef.current = value;
    startRef.current = performance.now();

    const animate = (now) => {
      const elapsed = now - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      // ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(fromRef.current + (target - fromRef.current) * eased);
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(animate);
      }
    };

    frameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameRef.current);
  }, [target, duration]);

  return value;
}

// ─────────────────────────────────────────────────
// HELPER COMPONENTS
// ─────────────────────────────────────────────────

const Card = ({ children, className = '', delay = 0 }) => (
  <div
    className={`glass-card p-5 md:p-6 animate-fade-in-up ${className}`}
    style={{ animationDelay: `${delay}ms` }}
  >
    {children}
  </div>
);

const RiskBadge = ({ risk }) => {
  let colorClasses = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
  let dotColor = 'bg-emerald-400';
  if (risk > 0.7) { colorClasses = 'bg-red-500/10 text-red-400 border-red-500/20'; dotColor = 'bg-red-400'; }
  else if (risk > 0.4) { colorClasses = 'bg-amber-500/10 text-amber-400 border-amber-500/20'; dotColor = 'bg-amber-400'; }

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold font-[var(--font-mono)] border ${colorClasses} transition-all duration-300`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dotColor} ${risk > 0.7 ? 'animate-pulse' : ''}`} />
      {(risk * 100).toFixed(1)}%
    </span>
  );
};

const MiniSparkline = ({ data, color = '#dc2626', height = 32 }) => {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 80;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={w} height={height} className="opacity-40 group-hover:opacity-70 transition-opacity duration-300">
      <defs>
        <linearGradient id={`grad-${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline fill="none" stroke={color} strokeWidth="1.5" points={points} strokeLinecap="round" strokeLinejoin="round" />
      <polygon
        fill={`url(#grad-${color.replace('#','')})`}
        points={`0,${height} ${points} ${w},${height}`}
      />
    </svg>
  );
};

const KpiCard = ({ label, value, suffix = '', prefix = '', icon: Icon, iconBg, iconColor, accentColor, sparkData, delay = 0, children }) => {
  const animatedVal = useAnimatedNumber(parseFloat(value) || 0);
  const displayVal = typeof value === 'number'
    ? (Number.isInteger(value) ? Math.round(animatedVal) : animatedVal.toFixed(1))
    : value;

  return (
    <Card className="group relative overflow-hidden hover:scale-[1.02] transition-transform duration-300" delay={delay}>
      <div className="flex items-start justify-between relative z-10">
        <div>
          <p className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">{label}</p>
          <h3 className={`text-3xl font-extrabold tracking-tight mt-1 ${accentColor || 'text-white'}`}>
            <span className="number-ticker">{prefix}{typeof value === 'number' ? displayVal.toLocaleString() : value}</span>
            {suffix && <span className="text-sm font-medium text-zinc-500 ml-1">{suffix}</span>}
          </h3>
          {children}
        </div>
        <div className={`p-2.5 rounded-xl ${iconBg || 'bg-zinc-800'} ${iconColor || 'text-zinc-400'} transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3`}>
          <Icon size={20} />
        </div>
      </div>
      {sparkData && (
        <div className="absolute bottom-0 right-0">
          <MiniSparkline data={sparkData} color={accentColor === 'text-red-400' ? '#ef4444' : accentColor === 'text-emerald-400' ? '#10b981' : '#71717a'} />
        </div>
      )}
    </Card>
  );
};

const Tooltip = ({ children, content, position = 'top' }) => {
  const posStyles = {
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 -translate-y-1/2 ml-2',
  };

  return (
    <div className="tooltip-container">
      {children}
      <div className={`tooltip-content ${posStyles[position]} whitespace-nowrap`}>
        <div className="bg-zinc-800 border border-zinc-700 text-zinc-200 text-xs font-medium px-3 py-2 rounded-lg shadow-xl">
          {content}
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────

export default function App() {
  const [selectedCommit, setSelectedCommit] = useState(MOCK_COMMITS[0].id);
  const [costPerHour, setCostPerHour] = useState(45);
  const [selectedModule, setSelectedModule] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: 'risk', direction: 'desc' });
  const [hoveredModule, setHoveredModule] = useState(null);
  const [isDispatching, setIsDispatching] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => { setMounted(true); }, []);

  const activeCommit = MOCK_COMMITS.find(c => c.id === selectedCommit);

  // Generate modules with active risk profile (deterministic)
  const activeModules = useMemo(() => {
    const risks = COMMIT_RISK_PROFILES[selectedCommit] || {};
    const rng = seededRandom(selectedCommit.length * 1000);
    return BASE_MODULES.map(mod => ({
      ...mod,
      risk: risks[mod.id] || (rng() * 0.15 + 0.01)
    }));
  }, [selectedCommit]);

  // Generate tests deterministically
  const currentTests = useMemo(() => {
    const tests = [];
    const rng = seededRandom(selectedCommit.charCodeAt(3) * 137);
    activeModules.forEach(mod => {
      const numTests = Math.floor(mod.loc / 3000) + 2;
      for (let i = 0; i < numTests; i++) {
        let testRisk = mod.risk + (rng() * 0.3 - 0.15);
        testRisk = Math.max(0.01, Math.min(0.99, testRisk));
        tests.push({
          id: `TB_${mod.id.toUpperCase()}_${String(i + 1).padStart(3, '0')}`,
          moduleId: mod.id,
          moduleName: mod.name,
          runtime: Math.floor(rng() * 90) + 10,
          passRate: 1 - (testRisk * 0.4),
          risk: testRisk,
        });
      }
    });
    return tests.sort((a, b) => b.risk - a.risk);
  }, [activeModules, selectedCommit]);

  // Filter & sort tests
  const filteredTests = useMemo(() => {
    let result = currentTests;
    if (selectedModule) result = result.filter(t => t.moduleId === selectedModule);
    if (searchQuery) result = result.filter(t => t.id.toLowerCase().includes(searchQuery.toLowerCase()) || t.moduleName.toLowerCase().includes(searchQuery.toLowerCase()));

    const { key, direction } = sortConfig;
    result = [...result].sort((a, b) => {
      const aVal = a[key];
      const bVal = b[key];
      if (typeof aVal === 'string') return direction === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      return direction === 'asc' ? aVal - bVal : bVal - aVal;
    });
    return result;
  }, [currentTests, selectedModule, searchQuery, sortConfig]);

  // Derived metrics
  const avgRisk = currentTests.reduce((acc, t) => acc + t.risk, 0) / currentTests.length;
  const highRiskTests = currentTests.filter(t => t.risk > 0.7).length;
  const totalRuntimeMins = currentTests.reduce((acc, t) => acc + t.runtime, 0);
  const totalRuntimeHours = totalRuntimeMins / 60;
  const baselineCost = totalRuntimeHours * costPerHour;
  const baselineTTFF = totalRuntimeMins * 0.65;
  const optimizedTTFF = totalRuntimeMins * 0.08;
  const timeSavedMins = baselineTTFF - optimizedTTFF;
  const costSaved = (timeSavedMins / 60) * costPerHour;
  const reductionPct = ((baselineTTFF - optimizedTTFF) / baselineTTFF * 100);

  // Fake sparkline data
  const sparkRisk = useMemo(() => [0.32, 0.35, 0.41, 0.38, 0.44, 0.42, avgRisk], [avgRisk]);
  const sparkCost = useMemo(() => [820, 780, 910, 870, 950, 920, baselineCost], [baselineCost]);
  const sparkSavings = useMemo(() => [380, 420, 460, 510, 490, 550, costSaved], [costSaved]);

  // ─── FAILURE INTELLIGENCE ───
  const activeFailures = useMemo(() => COMMIT_FAILURE_CLUSTERS[selectedCommit] || [], [selectedCommit]);
  const activeChanges = useMemo(() => RECENT_CHANGES[selectedCommit] || [], [selectedCommit]);

  // Error clustering: group failures by category
  const errorClusters = useMemo(() => {
    const clusters = {};
    ERROR_CATEGORIES.forEach(cat => { clusters[cat.id] = { ...cat, failures: [], totalAffected: 0 }; });
    activeFailures.forEach(f => {
      if (clusters[f.category]) {
        clusters[f.category].failures.push(f);
        clusters[f.category].totalAffected += f.affectedTests;
      }
    });
    return Object.values(clusters).filter(c => c.failures.length > 0).sort((a, b) => b.totalAffected - a.totalAffected);
  }, [activeFailures]);

  // Impact analysis: which modules are most affected
  const moduleImpact = useMemo(() => {
    const impact = {};
    activeFailures.forEach(f => {
      // Extract module from testId
      const parts = f.testId.split('_');
      const modKey = parts.slice(1, -1).join('_').toLowerCase();
      const mod = activeModules.find(m => m.id === modKey);
      if (!impact[modKey]) impact[modKey] = { moduleId: modKey, moduleName: mod?.name || modKey, failureCount: 0, totalAffected: 0, severities: [], categories: new Set() };
      impact[modKey].failureCount++;
      impact[modKey].totalAffected += f.affectedTests;
      impact[modKey].severities.push(f.severity);
      impact[modKey].categories.add(f.category);
    });
    return Object.values(impact).sort((a, b) => b.totalAffected - a.totalAffected);
  }, [activeFailures, activeModules]);

  // Prioritized failures: composite score = severity × affectedTests × recency
  const prioritizedFailures = useMemo(() => {
    return activeFailures.map(f => {
      const sevWeight = SEVERITY_ORDER[f.severity] || 1;
      const impactScore = f.affectedTests / 10;
      const changeCorrelation = activeChanges.some(c => f.relatedChange.includes(c.file)) ? 1.5 : 1.0;
      const debugPriority = (sevWeight * 0.4 + impactScore * 0.35 + changeCorrelation * 0.25) * 100;
      return { ...f, debugPriority: Math.min(99.9, debugPriority) };
    }).sort((a, b) => b.debugPriority - a.debugPriority);
  }, [activeFailures, activeChanges]);

  // Debug suggestions: top files to investigate
  const debugSuggestions = useMemo(() => {
    const fileMap = {};
    prioritizedFailures.forEach(f => {
      const file = f.relatedChange.split(':')[0];
      if (!fileMap[file]) fileMap[file] = { file, failures: [], maxPriority: 0, reasons: [] };
      fileMap[file].failures.push(f.id);
      fileMap[file].maxPriority = Math.max(fileMap[file].maxPriority, f.debugPriority);
      const reason = `${f.severity} ${ERROR_CATEGORIES.find(c => c.id === f.category)?.label || f.category} — ${f.affectedTests} tests affected`;
      if (!fileMap[file].reasons.includes(reason)) fileMap[file].reasons.push(reason);
    });
    return Object.values(fileMap).sort((a, b) => b.maxPriority - a.maxPriority);
  }, [prioritizedFailures]);

  // ─── UNIQUE SIGNATURE ANALYSIS ───
  const uniqueSignatures = useMemo(() => {
    const sigMap = {};
    activeFailures.forEach(f => {
      if (!sigMap[f.signature]) {
        sigMap[f.signature] = {
          signature: f.signature,
          category: f.category,
          signal: f.signal,
          severity: f.severity,
          recurrences: f.recurrences,
          firstSeen: f.firstSeen,
          lastSeen: f.lastSeen,
          isNew: f.recurrences === 1,
          failures: [],
          totalAffectedTests: 0,
          testIds: new Set(),
        };
      }
      sigMap[f.signature].failures.push(f);
      sigMap[f.signature].totalAffectedTests += f.affectedTests;
      sigMap[f.signature].testIds.add(f.testId);
      // Take worst severity
      if (SEVERITY_ORDER[f.severity] > SEVERITY_ORDER[sigMap[f.signature].severity]) {
        sigMap[f.signature].severity = f.severity;
      }
    });
    return Object.values(sigMap).sort((a, b) => {
      // Sort: new first, then by recurrences desc, then by affected tests desc
      if (a.isNew !== b.isNew) return a.isNew ? -1 : 1;
      if (b.recurrences !== a.recurrences) return b.recurrences - a.recurrences;
      return b.totalAffectedTests - a.totalAffectedTests;
    });
  }, [activeFailures]);

  const totalUniqueErrors = uniqueSignatures.length;
  const newErrors = uniqueSignatures.filter(s => s.isNew).length;
  const recurringErrors = uniqueSignatures.filter(s => !s.isNew).length;
  const maxRecurrence = Math.max(...uniqueSignatures.map(s => s.recurrences), 1);

  // Expanded failure detail
  const [expandedFailure, setExpandedFailure] = useState(null);

  // Sort handler
  const handleSort = useCallback((key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'desc' ? 'asc' : 'desc',
    }));
  }, []);

  // Dispatch simulation
  const handleDispatch = useCallback(() => {
    setIsDispatching(true);
    setTimeout(() => setIsDispatching(false), 3000);
  }, []);

  // ─── EXCEL EXPORT ───
  const handleExportExcel = useCallback(() => {
    const wb = XLSX.utils.book_new();

    // Sheet 1: Test Priority Queue
    const testRows = filteredTests.map((t, i) => ({
      '#': i + 1,
      'Test ID': t.id,
      'Target Module': t.moduleName,
      'Module ID': t.moduleId,
      'Runtime (min)': t.runtime,
      'Pass Rate': `${(t.passRate * 100).toFixed(1)}%`,
      'AI Risk Score': `${(t.risk * 100).toFixed(1)}%`,
      'Risk Level': t.risk > 0.7 ? 'HIGH' : t.risk > 0.4 ? 'MEDIUM' : 'LOW',
    }));
    const ws1 = XLSX.utils.json_to_sheet(testRows);
    ws1['!cols'] = [{ wch: 4 }, { wch: 22 }, { wch: 22 }, { wch: 14 }, { wch: 14 }, { wch: 12 }, { wch: 14 }, { wch: 12 }];
    XLSX.utils.book_append_sheet(wb, ws1, 'Test Priority Queue');

    // Sheet 2: Failure Intelligence
    const failRows = prioritizedFailures.map((f, i) => ({
      'Priority': `P${i + 1}`,
      'Failure ID': f.id,
      'Signature': f.signature,
      'Category': ERROR_CATEGORIES.find(c => c.id === f.category)?.label || f.category,
      'Severity': f.severity,
      'Signal': f.signal,
      'Error Message': f.message,
      'Recurrences': f.recurrences,
      'First Seen': f.firstSeen,
      'Last Seen': f.lastSeen,
      'Tests Affected': f.affectedTests,
      'Debug Priority Score': f.debugPriority.toFixed(1),
      'Related Change': f.relatedChange,
      'Source Test': f.testId,
    }));
    const ws2 = XLSX.utils.json_to_sheet(failRows);
    ws2['!cols'] = [{ wch: 8 }, { wch: 10 }, { wch: 16 }, { wch: 20 }, { wch: 10 }, { wch: 22 }, { wch: 60 }, { wch: 12 }, { wch: 16 }, { wch: 16 }, { wch: 14 }, { wch: 18 }, { wch: 45 }, { wch: 22 }];
    XLSX.utils.book_append_sheet(wb, ws2, 'Failure Intelligence');

    // Sheet 3: Unique Signatures
    const sigRows = uniqueSignatures.map(s => ({
      'Signature': s.signature,
      'Category': ERROR_CATEGORIES.find(c => c.id === s.category)?.label || s.category,
      'Signal': s.signal,
      'Severity': s.severity,
      'Recurrences': s.recurrences,
      'Tests Impacted': s.totalAffectedTests,
      'Unique Tests': s.testIds.size,
      'Status': s.isNew ? 'NEW' : 'RECURRING',
      'First Seen': s.firstSeen,
      'Last Seen': s.lastSeen,
    }));
    const ws3 = XLSX.utils.json_to_sheet(sigRows);
    ws3['!cols'] = [{ wch: 16 }, { wch: 20 }, { wch: 22 }, { wch: 10 }, { wch: 12 }, { wch: 14 }, { wch: 12 }, { wch: 12 }, { wch: 16 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, ws3, 'Unique Signatures');

    // Sheet 4: Module Impact
    const modRows = activeModules.map(m => {
      const impact = moduleImpact.find(mi => mi.moduleId === m.id);
      return {
        'Module ID': m.id,
        'Module Name': m.name,
        'Group': m.group,
        'Lines of Code': m.loc,
        'Risk Score': `${(m.risk * 100).toFixed(1)}%`,
        'Risk Level': m.risk > 0.7 ? 'HIGH' : m.risk > 0.4 ? 'MEDIUM' : 'LOW',
        'Failures': impact?.failureCount || 0,
        'Tests Affected': impact?.totalAffected || 0,
        'Error Types': impact?.categories?.size || 0,
      };
    });
    const ws4 = XLSX.utils.json_to_sheet(modRows);
    ws4['!cols'] = [{ wch: 14 }, { wch: 24 }, { wch: 14 }, { wch: 14 }, { wch: 12 }, { wch: 12 }, { wch: 10 }, { wch: 14 }, { wch: 12 }];
    XLSX.utils.book_append_sheet(wb, ws4, 'Module Impact');

    // Download
    const commitLabel = selectedCommit.replace(/[^a-zA-Z0-9]/g, '_');
    XLSX.writeFile(wb, `SanDisk_Optima_${commitLabel}_${new Date().toISOString().slice(0,10)}.xlsx`);
  }, [filteredTests, prioritizedFailures, uniqueSignatures, activeModules, moduleImpact, selectedCommit]);

  const SortIcon = ({ column }) => {
    if (sortConfig.key !== column) return <ArrowUpDown size={12} className="opacity-30 group-hover:opacity-60 transition-opacity" />;
    return sortConfig.direction === 'asc'
      ? <ArrowUp size={12} className="text-red-400" />
      : <ArrowDown size={12} className="text-red-400" />;
  };

  const rangeProgress = ((costPerHour - 10) / (200 - 10)) * 100;

  return (
    <div className={`min-h-screen bg-zinc-950 text-zinc-300 flex flex-col md:flex-row selection:bg-red-500/30 ${mounted ? 'opacity-100' : 'opacity-0'} transition-opacity duration-500`}>

      {/* ──── SIDEBAR ──── */}
      <aside className={`${sidebarCollapsed ? 'w-full md:w-20' : 'w-full md:w-80'} bg-zinc-950 border-r border-zinc-800/60 flex flex-col relative z-20 transition-all duration-500 ease-out`}>
        <div className="p-5 flex-1 flex flex-col overflow-hidden">

          {/* Logo */}
          <div className={`flex items-center gap-3 mb-8 animate-slide-in-left ${sidebarCollapsed ? 'justify-center' : ''}`}>
            <div className="p-2.5 bg-gradient-to-br from-red-600 to-red-700 rounded-xl text-white shadow-[0_0_20px_rgba(220,38,38,0.4)] flex-shrink-0 transition-transform duration-300 hover:scale-105">
              <HardDrive size={22} />
            </div>
            {!sidebarCollapsed && (
              <div className="overflow-hidden">
                <h1 className="text-lg font-extrabold tracking-tight text-white leading-tight">SanDisk Optima</h1>
                <p className="text-[10px] text-zinc-500 font-semibold tracking-[0.2em] uppercase">AI RTL Verification</p>
              </div>
            )}
          </div>

          {/* Collapse toggle */}
          <button
            onClick={() => setSidebarCollapsed(v => !v)}
            className="hidden md:flex absolute top-5 right-0 translate-x-1/2 w-6 h-6 bg-zinc-800 border border-zinc-700 rounded-full items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-700 transition-all z-30 shadow-md"
            title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {sidebarCollapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
          </button>

          {!sidebarCollapsed && (
            <div className="space-y-7 flex-1 animate-fade-in">

              {/* Pipeline Context */}
              <div>
                <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                  <Layers size={12} /> Pipeline Context
                </h3>
                <div className="space-y-2">
                  <label className="text-xs text-zinc-400 font-medium">Target Commit</label>
                  <select
                    value={selectedCommit}
                    onChange={(e) => { setSelectedCommit(e.target.value); setSelectedModule(null); }}
                    className="custom-select w-full bg-zinc-900 border border-zinc-700/50 rounded-xl p-3 text-sm text-white focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all appearance-none cursor-pointer hover:border-zinc-600"
                  >
                    {MOCK_COMMITS.map(c => (
                      <option key={c.id} value={c.id}>{c.id.split('_').pop()} — {c.author}</option>
                    ))}
                  </select>
                </div>

                <div className="mt-3 p-4 bg-zinc-900/60 border border-zinc-800/80 rounded-xl space-y-3">
                  <div>
                    <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider mb-1">Commit Message</p>
                    <p className="text-sm font-medium text-zinc-200 leading-relaxed">{activeCommit.message}</p>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-3 border-t border-zinc-800/60">
                    <div className="text-center">
                      <p className="text-[10px] text-zinc-500 font-medium">Files</p>
                      <p className="text-sm font-bold text-zinc-200 font-[var(--font-mono)]">{activeCommit.files}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] text-emerald-500 font-medium">+Lines</p>
                      <p className="text-sm font-bold text-emerald-400 font-[var(--font-mono)]">{activeCommit.insertions}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] text-red-500 font-medium">-Lines</p>
                      <p className="text-sm font-bold text-red-400 font-[var(--font-mono)]">{activeCommit.deletions}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-3 border-t border-zinc-800/60">
                    <span className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider">Churn Level</span>
                    <span className={`chip-status ${
                      activeCommit.churn === 'High' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                      activeCommit.churn === 'Medium' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                      'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        activeCommit.churn === 'High' ? 'bg-red-400 animate-pulse' :
                        activeCommit.churn === 'Medium' ? 'bg-amber-400' :
                        'bg-emerald-400'
                      }`} />
                      {activeCommit.churn}
                    </span>
                  </div>
                </div>
              </div>

              {/* Farm Parameters */}
              <div>
                <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                  <Cpu size={12} /> Farm Parameters
                </h3>
                <div className="space-y-3">
                  <label className="text-xs text-zinc-400 font-medium flex justify-between items-center">
                    Compute Cost
                    <span className="text-white font-[var(--font-mono)] font-bold bg-zinc-800 px-3 py-1.5 rounded-lg text-sm border border-zinc-700/80 shadow-inner">
                      ${costPerHour}/hr
                    </span>
                  </label>
                  <input
                    type="range"
                    min="10" max="200" step="5"
                    value={costPerHour}
                    onChange={(e) => setCostPerHour(Number(e.target.value))}
                    className="w-full cursor-pointer"
                    style={{ '--range-progress': `${rangeProgress}%` }}
                  />
                  <div className="flex justify-between text-[10px] text-zinc-600 font-[var(--font-mono)]">
                    <span>$10</span>
                    <span>$200</span>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="p-4 bg-zinc-900/40 border border-zinc-800/60 rounded-xl">
                <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] mb-3 flex items-center gap-2">
                  <BarChart3 size={12} /> Session Stats
                </h3>
                <div className="space-y-2.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500">Total Tests</span>
                    <span className="text-white font-bold font-[var(--font-mono)]">{currentTests.length}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500">Total Runtime</span>
                    <span className="text-white font-bold font-[var(--font-mono)]">{(totalRuntimeMins/60).toFixed(1)}h</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500">Coverage</span>
                    <span className="text-emerald-400 font-bold font-[var(--font-mono)]">7/7 IPs</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Dispatch Button */}
          {!sidebarCollapsed && (
            <div className="mt-auto pt-5">
              <button
                onClick={handleDispatch}
                disabled={isDispatching}
                className={`btn-dispatch w-full text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2.5 transition-all active:scale-[0.97] shadow-lg ${
                  isDispatching
                    ? 'bg-zinc-700 cursor-wait shadow-none'
                    : 'bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 shadow-red-600/25 hover:shadow-red-500/40'
                }`}
              >
                {isDispatching ? (
                  <>
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
                    Dispatching…
                  </>
                ) : (
                  <>
                    <Zap size={16} />
                    Dispatch AI Regression
                  </>
                )}
              </button>
              <p className="text-[10px] text-zinc-600 text-center mt-2.5 font-medium">
                Estimated: {Math.round(optimizedTTFF)}min to first failure
              </p>
            </div>
          )}
        </div>
      </aside>

      {/* ──── MAIN CONTENT ──── */}
      <main className="flex-1 p-5 lg:p-8 overflow-y-auto relative">
        {/* Ambient glow */}
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-red-500/[0.03] blur-[150px] rounded-full pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-emerald-500/[0.02] blur-[120px] rounded-full pointer-events-none" />

        {/* Header */}
        <header className="mb-8 relative z-10 animate-fade-in-up">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-1 h-8 bg-gradient-to-b from-red-500 to-red-700 rounded-full" />
            <div>
              <h2 className="text-2xl font-extrabold text-white tracking-tight">Regression Optimizer</h2>
              <p className="text-zinc-500 text-sm">Predictive failure routing for SoC verification pipelines.</p>
            </div>
          </div>
        </header>

        {/* ──── KPI CARDS ──── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8 relative z-10">
          <KpiCard
            label="Avg Failure Prob"
            value={parseFloat((avgRisk * 100).toFixed(1))}
            suffix="%"
            icon={Activity}
            iconBg="bg-zinc-800"
            iconColor="text-zinc-400"
            sparkData={sparkRisk.map(v => v * 100)}
            delay={50}
          />
          <KpiCard
            label="High-Risk Tests"
            value={highRiskTests}
            suffix={`/ ${currentTests.length}`}
            icon={AlertTriangle}
            iconBg="bg-red-500/10"
            iconColor="text-red-400"
            accentColor="text-red-400"
            sparkData={[3, 5, 4, 7, 6, 8, highRiskTests]}
            delay={100}
          />
          <KpiCard
            label="Baseline Compute"
            value={parseFloat(baselineCost.toFixed(0))}
            prefix="$"
            icon={Clock}
            iconBg="bg-zinc-800"
            iconColor="text-zinc-400"
            sparkData={sparkCost}
            delay={150}
          />
          <KpiCard
            label="Projected Savings"
            value={parseFloat(costSaved.toFixed(0))}
            prefix="+$"
            icon={DollarSign}
            iconBg="bg-emerald-500/10"
            iconColor="text-emerald-400"
            accentColor="text-emerald-400"
            sparkData={sparkSavings}
            delay={200}
          >
            <p className="text-[10px] text-emerald-500/60 mt-1 font-semibold">{reductionPct.toFixed(0)}% TTFF reduction</p>
          </KpiCard>
        </div>

        {/* ──── FLOORPLAN + TABLE ──── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-8 relative z-10">

          {/* SoC RTL BLOCK HEATMAP */}
          <div className="lg:col-span-1 flex flex-col">
            <Card className="h-full flex flex-col !p-4" delay={250}>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <CircuitBoard size={15} className="text-red-400" /> RTL Block Heatmap
                </h3>
                {selectedModule && (
                  <button
                    onClick={() => setSelectedModule(null)}
                    className="text-[10px] uppercase font-bold tracking-wider flex items-center gap-1 text-zinc-400 hover:text-white bg-zinc-800 px-2 py-1 rounded-md transition-all border border-zinc-700 hover:border-zinc-600 hover:bg-zinc-700"
                  >
                    Clear <X size={10} />
                  </button>
                )}
              </div>
              <p className="text-[10px] text-zinc-600 mb-3 font-[var(--font-mono)] tracking-wider">
                RISK-WEIGHTED RTL SUBSYSTEM VIEW
              </p>

              {/* RTL Block Grid */}
              <div className="flex-1 w-full space-y-2">
                {/* Group modules by subsystem */}
                {[
                  { label: 'Host Interface', ids: ['pcie_mac', 'nvme_ctrl'] },
                  { label: 'Processing', ids: ['aes_crypto', 'ftl_core'] },
                  { label: 'Data Path', ids: ['ecc_ldpc', 'dram_ctrl'] },
                  { label: 'Storage IO', ids: ['nand_onfi'] },
                ].map((group) => {
                  const mods = group.ids.map(id => activeModules.find(m => m.id === id)).filter(Boolean);
                  if (mods.length === 0) return null;

                  return (
                    <div key={group.label}>
                      <p className="text-[8px] text-zinc-600 font-[var(--font-mono)] uppercase tracking-[0.2em] mb-1">{group.label}</p>
                      <div className={`grid gap-1.5 ${mods.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                        {mods.map((mod) => {
                          const isSelected = selectedModule === mod.id;
                          const isHovered = hoveredModule === mod.id;
                          const isDimmed = selectedModule && !isSelected;
                          const riskPct = mod.risk * 100;
                          const failureCount = (activeFailures || []).filter(f => {
                            const parts = f.testId.split('_');
                            const modKey = parts.slice(1, -1).join('_').toLowerCase();
                            return modKey === mod.id;
                          }).length;

                          // Continuous heat gradient
                          const heatColor = riskPct > 70
                            ? `rgba(239, 68, 68, ${0.15 + mod.risk * 0.5})`
                            : riskPct > 40
                              ? `rgba(245, 158, 11, ${0.1 + mod.risk * 0.35})`
                              : `rgba(16, 185, 129, ${0.05 + mod.risk * 0.2})`;

                          const borderHeat = riskPct > 70
                            ? `rgba(239, 68, 68, ${isSelected || isHovered ? 0.9 : 0.5})`
                            : riskPct > 40
                              ? `rgba(245, 158, 11, ${isSelected || isHovered ? 0.8 : 0.35})`
                              : `rgba(16, 185, 129, ${isSelected || isHovered ? 0.6 : 0.2})`;

                          const textHeat = riskPct > 70 ? '#fca5a5' : riskPct > 40 ? '#fcd34d' : 'rgba(110,231,183,0.8)';

                          return (
                            <button
                              key={mod.id}
                              onClick={() => setSelectedModule(isSelected ? null : mod.id)}
                              onMouseEnter={() => setHoveredModule(mod.id)}
                              onMouseLeave={() => setHoveredModule(null)}
                              className="relative rounded-lg border p-2 text-left transition-all duration-300 ease-out outline-none overflow-hidden group"
                              style={{
                                background: heatColor,
                                borderColor: borderHeat,
                                opacity: isDimmed ? 0.2 : 1,
                                filter: isDimmed ? 'grayscale(0.8)' : 'none',
                                transform: isSelected ? 'scale(1.03)' : isHovered ? 'scale(1.01)' : 'scale(1)',
                                boxShadow: isSelected
                                  ? `0 0 15px rgba(0,0,0,0.5), inset 0 0 15px ${riskPct > 70 ? 'rgba(220,38,38,0.15)' : 'transparent'}`
                                  : riskPct > 70 ? 'inset 0 0 20px rgba(220,38,38,0.1)' : 'none',
                              }}
                            >
                              {/* Pulse overlay for critical */}
                              {riskPct > 70 && (
                                <div className="absolute inset-0 rounded-lg border border-red-500/30" style={{ animation: 'pulseGlow 2s ease-in-out infinite' }} />
                              )}

                              {/* Top row: group + risk pill */}
                              <div className="flex items-center justify-between mb-1 relative z-10">
                                <span className="text-[7px] uppercase tracking-[0.15em] font-[var(--font-mono)] font-bold opacity-50" style={{ color: textHeat }}>
                                  {mod.group}
                                </span>
                                <span
                                  className="text-[8px] font-[var(--font-mono)] font-bold px-1.5 py-0.5 rounded bg-black/50 border border-white/10"
                                  style={{ color: textHeat }}
                                >
                                  {riskPct.toFixed(0)}%
                                </span>
                              </div>

                              {/* Module name */}
                              <p className="text-[10px] font-bold tracking-tight leading-tight relative z-10" style={{ color: textHeat }}>
                                {mod.name}
                              </p>

                              {/* Bottom: LOC + failures */}
                              <div className="flex items-center justify-between mt-1.5 relative z-10">
                                <span className="text-[7px] font-[var(--font-mono)] opacity-40" style={{ color: textHeat }}>
                                  {Math.round(mod.loc / 1000)}K LOC
                                </span>
                                {failureCount > 0 && (
                                  <span className="text-[7px] font-[var(--font-mono)] font-bold bg-red-500/20 text-red-400 border border-red-500/30 px-1 py-0.5 rounded">
                                    {failureCount} fail{failureCount > 1 ? 's' : ''}
                                  </span>
                                )}
                              </div>

                              {/* Heat bar at bottom */}
                              <div className="absolute bottom-0 left-0 right-0 h-1 overflow-hidden rounded-b-lg">
                                <div
                                  className="h-full rounded-b-lg animate-bar-grow"
                                  style={{
                                    width: `${riskPct}%`,
                                    background: riskPct > 70 ? '#ef4444' : riskPct > 40 ? '#f59e0b' : '#10b981',
                                    animationDelay: '0.3s',
                                  }}
                                />
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}

                {/* Legend */}
                <div className="flex items-center gap-3 pt-2 border-t border-zinc-800/50 mt-2">
                  <span className="text-[8px] text-zinc-600 font-semibold uppercase tracking-wider">Risk</span>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-2 rounded-sm bg-emerald-500/40" />
                    <span className="text-[7px] text-zinc-600">Low</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-2 rounded-sm bg-amber-500/50" />
                    <span className="text-[7px] text-zinc-600">Med</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-2 rounded-sm bg-red-500/60" />
                    <span className="text-[7px] text-zinc-600">High</span>
                  </div>
                </div>
              </div>

              {/* Hovered module detail */}
              {hoveredModule && (
                <div className="mt-3 px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-xs animate-fade-in">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-white">{activeModules.find(m => m.id === hoveredModule)?.name}</span>
                    <RiskBadge risk={activeModules.find(m => m.id === hoveredModule)?.risk || 0} />
                  </div>
                  <p className="text-zinc-500 mt-1 font-[var(--font-mono)] text-[10px]">
                    {(activeModules.find(m => m.id === hoveredModule)?.loc || 0).toLocaleString()} Lines of Code
                  </p>
                </div>
              )}
            </Card>
          </div>

          {/* ──── TEST PRIORITY TABLE ──── */}
          <div className="lg:col-span-2 flex flex-col">
            <Card className="h-full flex flex-col" delay={300}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Layout size={15} className="text-red-400" /> Test Priority Queue
                  </h3>
                  {selectedModule && (
                    <span className="flex items-center gap-1.5 bg-red-500/10 text-red-400 border border-red-500/20 px-2.5 py-1 rounded-full text-[10px] font-semibold animate-fade-in">
                      <Filter size={10} /> {activeModules.find(m => m.id === selectedModule)?.name}
                      <button onClick={() => setSelectedModule(null)} className="hover:text-white transition-colors ml-0.5"><X size={10} /></button>
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportExcel}
                    className="flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1.5 rounded-lg text-[10px] font-semibold hover:bg-emerald-500/20 hover:border-emerald-500/30 transition-all"
                    title="Export all test data and failure analysis to Excel"
                  >
                    <Download size={11} /> Export XLSX
                  </button>
                  <div className="relative">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
                  <input
                    type="text"
                    placeholder="Search tests…"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full sm:w-52 bg-zinc-950 border border-zinc-800 rounded-lg pl-9 pr-4 py-2 text-xs text-zinc-300 focus:outline-none focus:border-red-500/60 focus:ring-1 focus:ring-red-500/30 transition-all placeholder:text-zinc-600"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white transition-colors">
                      <X size={12} />
                    </button>
                  )}
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-auto border border-zinc-800/60 rounded-xl bg-zinc-950/80">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-900/90 text-zinc-500 sticky top-0 z-10 backdrop-blur-md border-b border-zinc-800/80">
                    <tr>
                      <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">#</th>
                      {[
                        { key: 'id', label: 'Test ID', align: 'text-left' },
                        { key: 'moduleName', label: 'Target IP', align: 'text-left' },
                        { key: 'runtime', label: 'Cost', align: 'text-right' },
                        { key: 'risk', label: 'AI Risk', align: 'text-right' },
                      ].map(col => (
                        <th
                          key={col.key}
                          onClick={() => handleSort(col.key)}
                          className={`px-4 py-3 font-semibold text-[10px] uppercase tracking-wider ${col.align} cursor-pointer select-none group hover:text-zinc-300 transition-colors`}
                        >
                          <span className="inline-flex items-center gap-1.5">
                            {col.label}
                            <SortIcon column={col.key} />
                          </span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/30">
                    {filteredTests.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-4 py-12 text-center text-zinc-600">
                          <Search size={20} className="mx-auto mb-2 opacity-30" />
                          No tests match this selection.
                        </td>
                      </tr>
                    ) : filteredTests.slice(0, 18).map((test, idx) => (
                      <tr
                        key={test.id}
                        className="table-row-interactive group"
                        style={{ animationDelay: `${idx * 20}ms` }}
                      >
                        <td className="px-4 py-2.5 text-zinc-600 font-[var(--font-mono)] text-[10px]">
                          {String(idx + 1).padStart(2, '0')}
                        </td>
                        <td className="px-4 py-2.5 font-[var(--font-mono)] text-zinc-300 text-[11px]">
                          <div className="flex items-center gap-2">
                            {idx < 3 && !selectedModule && (
                              <span className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)]" style={{ animation: 'pulseGlow 1.5s ease-in-out infinite' }} />
                            )}
                            {test.id}
                          </div>
                        </td>
                        <td className="px-4 py-2.5 text-zinc-400 font-medium text-[11px]">
                          <button
                            onClick={() => setSelectedModule(test.moduleId === selectedModule ? null : test.moduleId)}
                            className="hover:text-white transition-colors hover:underline underline-offset-2 decoration-zinc-600"
                          >
                            {test.moduleName}
                          </button>
                        </td>
                        <td className="px-4 py-2.5 text-right font-[var(--font-mono)] font-bold text-zinc-300 text-[11px]">{test.runtime}m</td>
                        <td className="px-4 py-2.5 text-right">
                          <RiskBadge risk={test.risk} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-3 flex items-center justify-between text-[10px] text-zinc-600 font-medium px-1">
                <span>Showing {Math.min(18, filteredTests.length)} of {filteredTests.length} tests</span>
                <span className="flex items-center gap-1.5">
                  Sorted by <span className="text-zinc-400 font-semibold">{sortConfig.key}</span>
                  {sortConfig.direction === 'asc' ? <ArrowUp size={10} /> : <ArrowDown size={10} />}
                </span>
              </div>
            </Card>
          </div>
        </div>

        {/* ──── ROI / TTFF PANEL ──── */}
        <Card className="relative overflow-hidden" delay={400}>
          <div className="absolute top-0 right-0 p-8 opacity-[0.015] pointer-events-none">
            <TrendingDown size={220} />
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 relative z-10">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Timer size={15} className="text-emerald-400" /> Compute Time-to-First-Failure (TTFF)
              </h3>
              <p className="text-xs text-zinc-500 mt-1">Standard FIFO queue vs. AI-optimized priority queue.</p>
            </div>
            <div className="mt-3 md:mt-0 px-4 py-2 bg-zinc-800/40 border border-zinc-700/40 rounded-lg text-[10px] text-zinc-400 font-medium flex items-center gap-2">
              <Gauge size={12} className="text-zinc-500" />
              SanDisk Goal: <span className="text-white font-semibold">80% bugs found in 20% runtime</span>
            </div>
          </div>

          <div className="space-y-6 relative z-10">
            {/* Baseline */}
            <div>
              <div className="flex justify-between text-xs mb-2">
                <span className="text-zinc-400 font-medium flex items-center gap-2">
                  <XCircle size={14} className="text-zinc-600" /> Baseline Regression (Run All)
                </span>
                <span className="text-zinc-400 font-[var(--font-mono)] font-bold">{Math.round(baselineTTFF).toLocaleString()} mins</span>
              </div>
              <div className="w-full bg-zinc-950 rounded-full h-4 border border-zinc-800/60 flex overflow-hidden p-0.5 relative">
                <div
                  className="bg-gradient-to-r from-zinc-700 to-zinc-600 h-full rounded-full animate-bar-grow relative"
                  style={{ width: '65%', animationDelay: '0.5s' }}
                >
                  <div className="absolute right-0 top-0 bottom-0 w-6 bg-gradient-to-r from-transparent to-zinc-600" />
                </div>
                <div className="bg-red-500 h-full w-1.5 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.8)] -ml-0.5 z-10 flex-shrink-0" />
              </div>
            </div>

            {/* Optimized */}
            <div>
              <div className="flex justify-between text-xs mb-2">
                <span className="text-white font-semibold flex items-center gap-2">
                  <CheckCircle size={14} className="text-emerald-500" /> CoreOptima AI (Smart Order)
                </span>
                <span className="text-emerald-400 font-[var(--font-mono)] font-extrabold text-base">{Math.round(optimizedTTFF).toLocaleString()} mins</span>
              </div>
              <div className="w-full bg-zinc-950 rounded-full h-4 border border-zinc-800/60 flex overflow-hidden p-0.5 relative">
                <div
                  className="bg-gradient-to-r from-emerald-600 to-emerald-400 h-full rounded-full animate-bar-grow relative"
                  style={{ width: '8%', animationDelay: '0.8s' }}
                >
                  <div className="absolute inset-0 bg-white/10 animate-pulse rounded-full" />
                </div>
                <div className="bg-red-500 h-full w-1.5 rounded-full shadow-[0_0_10px_rgba(239,68,68,1)] -ml-0.5 z-10 flex-shrink-0" />
              </div>
            </div>

            {/* Summary stats row */}
            <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-zinc-800/50">
              <div className="flex items-center gap-2 px-3 py-2 bg-emerald-500/5 border border-emerald-500/15 rounded-lg">
                <Zap size={14} className="text-emerald-400" />
                <div>
                  <p className="text-[10px] text-emerald-500/70 font-semibold uppercase tracking-wider">Time Saved</p>
                  <p className="text-sm font-bold text-emerald-400 font-[var(--font-mono)]">{Math.round(timeSavedMins)} mins</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-emerald-500/5 border border-emerald-500/15 rounded-lg">
                <TrendingDown size={14} className="text-emerald-400" />
                <div>
                  <p className="text-[10px] text-emerald-500/70 font-semibold uppercase tracking-wider">TTFF Reduction</p>
                  <p className="text-sm font-bold text-emerald-400 font-[var(--font-mono)]">{reductionPct.toFixed(1)}%</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-emerald-500/5 border border-emerald-500/15 rounded-lg">
                <DollarSign size={14} className="text-emerald-400" />
                <div>
                  <p className="text-[10px] text-emerald-500/70 font-semibold uppercase tracking-wider">Cost Efficiency</p>
                  <p className="text-sm font-bold text-emerald-400 font-[var(--font-mono)]">${Math.round(costSaved)}</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* ──── FAILURE INTELLIGENCE SECTION ──── */}
        <div className="relative z-10 mt-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1 h-8 bg-gradient-to-b from-purple-500 to-purple-700 rounded-full" />
            <div>
              <h2 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
                <Bug size={20} className="text-purple-400" /> Failure Intelligence
              </h2>
              <p className="text-zinc-500 text-xs">Unique error signatures, clustering, impact analysis, and debug prioritization.</p>
            </div>
          </div>

          {/* ──── UNIQUE ERROR SIGNATURES ──── */}
          <Card className="mb-6" delay={430}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Fingerprint size={15} className="text-purple-400" /> Unique Error Signatures
              </h3>
              <div className="flex items-center gap-2">
                <span className="chip-status bg-purple-500/10 text-purple-400 border border-purple-500/20">
                  <Scan size={10} /> {totalUniqueErrors} unique
                </span>
                {newErrors > 0 && (
                  <span className="chip-status bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    <Sparkles size={10} /> {newErrors} new
                  </span>
                )}
                <span className="chip-status bg-zinc-500/10 text-zinc-400 border border-zinc-500/20">
                  <Repeat size={10} /> {recurringErrors} recurring
                </span>
              </div>
            </div>

            <div className="overflow-auto border border-zinc-800/60 rounded-xl bg-zinc-950/80">
              <table className="w-full text-left text-xs">
                <thead className="bg-zinc-900/90 text-zinc-500 sticky top-0 z-10 backdrop-blur-md border-b border-zinc-800/80">
                  <tr>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Signature</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Category</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Signal</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider text-center">Recurrences</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider text-center">Tests Impacted</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Severity</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider hidden lg:table-cell">First Seen</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/30">
                  {uniqueSignatures.map((sig) => {
                    const catInfo = ERROR_CATEGORIES.find(c => c.id === sig.category);
                    const sevStyle = SEVERITY_COLORS[sig.severity];
                    const recurrencePct = (sig.recurrences / maxRecurrence) * 100;

                    return (
                      <tr key={sig.signature} className="table-row-interactive group">
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-1.5">
                            <Fingerprint size={11} className="text-purple-400/60" />
                            <span className="font-[var(--font-mono)] text-[10px] text-purple-300 font-bold tracking-wide">{sig.signature}</span>
                          </div>
                        </td>
                        <td className="px-4 py-2.5">
                          <span className={`chip-status ${catInfo?.bgClass || ''}`}>{catInfo?.label || sig.category}</span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span className="font-[var(--font-mono)] text-[10px] text-zinc-400">{sig.signal}</span>
                        </td>
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-2 justify-center">
                            <div className="w-16 bg-zinc-950 rounded-full h-1.5 overflow-hidden border border-zinc-800/40">
                              <div
                                className="h-full rounded-full animate-bar-grow"
                                style={{
                                  width: `${recurrencePct}%`,
                                  background: sig.recurrences > 6 ? '#ef4444' : sig.recurrences > 3 ? '#f59e0b' : '#71717a',
                                  animationDelay: '0.4s',
                                }}
                              />
                            </div>
                            <span className={`font-[var(--font-mono)] font-extrabold text-[11px] min-w-[20px] text-right ${
                              sig.recurrences > 6 ? 'text-red-400' : sig.recurrences > 3 ? 'text-amber-400' : 'text-zinc-300'
                            }`}>{sig.recurrences}×</span>
                          </div>
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <span className="font-[var(--font-mono)] font-bold text-zinc-200 text-[11px]">{sig.totalAffectedTests}</span>
                          <span className="text-zinc-600 text-[10px] ml-1">tests</span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span className={`chip-status ${sevStyle.bg} ${sevStyle.text} border ${sevStyle.border}`}>
                            <span className={`w-1 h-1 rounded-full ${sevStyle.dot}`} />
                            {sig.severity}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 hidden lg:table-cell">
                          <span className="font-[var(--font-mono)] text-[10px] text-zinc-500">{sig.firstSeen}</span>
                        </td>
                        <td className="px-4 py-2.5">
                          {sig.isNew ? (
                            <span className="chip-status bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              <Sparkles size={9} /> New
                            </span>
                          ) : (
                            <span className="chip-status bg-zinc-500/10 text-zinc-400 border border-zinc-500/20">
                              <Repeat size={9} /> Recurring
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Summary ribbon */}
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-2 bg-purple-500/5 border border-purple-500/15 rounded-lg">
                <Fingerprint size={13} className="text-purple-400" />
                <div>
                  <p className="text-[10px] text-purple-400/70 font-semibold uppercase tracking-wider">Unique Signatures</p>
                  <p className="text-sm font-bold text-purple-400 font-[var(--font-mono)]">{totalUniqueErrors}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-emerald-500/5 border border-emerald-500/15 rounded-lg">
                <Sparkles size={13} className="text-emerald-400" />
                <div>
                  <p className="text-[10px] text-emerald-400/70 font-semibold uppercase tracking-wider">New This Run</p>
                  <p className="text-sm font-bold text-emerald-400 font-[var(--font-mono)]">{newErrors}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-amber-500/5 border border-amber-500/15 rounded-lg">
                <Repeat size={13} className="text-amber-400" />
                <div>
                  <p className="text-[10px] text-amber-400/70 font-semibold uppercase tracking-wider">Avg Recurrence</p>
                  <p className="text-sm font-bold text-amber-400 font-[var(--font-mono)]">{(uniqueSignatures.reduce((s, e) => s + e.recurrences, 0) / (totalUniqueErrors || 1)).toFixed(1)}×</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-red-500/5 border border-red-500/15 rounded-lg">
                <AlertTriangle size={13} className="text-red-400" />
                <div>
                  <p className="text-[10px] text-red-400/70 font-semibold uppercase tracking-wider">Total Test Impact</p>
                  <p className="text-sm font-bold text-red-400 font-[var(--font-mono)]">{uniqueSignatures.reduce((s, e) => s + e.totalAffectedTests, 0)} tests</p>
                </div>
              </div>
            </div>
          </Card>

          {/* ──── ERROR CLUSTERING & CATEGORIZED SUMMARY ──── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6">
            
            {/* Categorized Error Summary */}
            <Card delay={450}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Hash size={15} className="text-purple-400" /> Error Clustering
                </h3>
                <span className="text-[10px] font-semibold text-zinc-500 bg-zinc-800 px-2 py-1 rounded-md border border-zinc-700">
                  {activeFailures.length} failures · {errorClusters.length} clusters
                </span>
              </div>

              <div className="space-y-3">
                {errorClusters.map((cluster) => {
                  const IconMap = { Clock, AlertOctagon, ShieldAlert, Database, Flame };
                  const ClusterIcon = IconMap[cluster.icon] || AlertTriangle;
                  const pct = (cluster.failures.length / activeFailures.length * 100).toFixed(0);
                  
                  return (
                    <div key={cluster.id} className="group">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className={`p-1.5 rounded-lg ${cluster.bgClass.split(' ')[0]} border ${cluster.bgClass.split(' ').pop()}`}>
                            <ClusterIcon size={13} style={{ color: cluster.color }} />
                          </div>
                          <div>
                            <span className="text-xs font-semibold text-zinc-200">{cluster.label}</span>
                            <span className="text-[10px] text-zinc-500 ml-2 font-[var(--font-mono)]">{cluster.failures.length} failures</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-semibold text-zinc-400 font-[var(--font-mono)]">{cluster.totalAffected} tests affected</span>
                          <span className="text-[10px] font-bold text-zinc-500">{pct}%</span>
                        </div>
                      </div>
                      {/* Bar */}
                      <div className="w-full bg-zinc-950 rounded-full h-2 border border-zinc-800/60 overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-700 animate-bar-grow"
                          style={{ width: `${pct}%`, background: cluster.color, animationDelay: '0.3s' }}
                        />
                      </div>
                    </div>
                  );
                })}

                {errorClusters.length === 0 && (
                  <div className="py-8 text-center text-zinc-600 text-xs">No failures detected for this commit.</div>
                )}
              </div>
            </Card>

            {/* Impact Analysis — Modules Affected */}
            <Card delay={500}>
              <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
                <Target size={15} className="text-red-400" /> Impact Analysis
              </h3>

              <div className="space-y-3 mb-4">
                {moduleImpact.map((mod) => {
                  const maxSev = mod.severities.reduce((max, s) => SEVERITY_ORDER[s] > SEVERITY_ORDER[max] ? s : max, 'low');
                  const sevStyle = SEVERITY_COLORS[maxSev];
                  
                  return (
                    <div key={mod.moduleId} className="flex items-center gap-3 p-3 bg-zinc-950/60 border border-zinc-800/50 rounded-xl hover:border-zinc-700 transition-all group">
                      <div className={`w-2 h-8 rounded-full ${sevStyle.dot} flex-shrink-0 ${maxSev === 'critical' ? 'animate-pulse' : ''}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">{mod.moduleName}</span>
                          <span className={`chip-status ${sevStyle.bg} ${sevStyle.text} border ${sevStyle.border}`}>
                            {maxSev}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-[10px] text-zinc-500">
                            <span className="font-bold text-zinc-300 font-[var(--font-mono)]">{mod.failureCount}</span> failures
                          </span>
                          <span className="text-[10px] text-zinc-500">
                            <span className="font-bold text-zinc-300 font-[var(--font-mono)]">{mod.totalAffected}</span> tests hit
                          </span>
                          <span className="text-[10px] text-zinc-500">
                            <span className="font-bold text-zinc-300 font-[var(--font-mono)]">{mod.categories.size}</span> error types
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Related Recent Changes */}
              <div className="pt-3 border-t border-zinc-800/50">
                <h4 className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.15em] flex items-center gap-1.5 mb-2.5">
                  <GitCommit size={11} /> Recent Changes Linked to Failures
                </h4>
                <div className="space-y-2">
                  {activeChanges.filter(c => c.riskScore > 0.4).map((change, i) => (
                    <div key={i} className="flex items-start gap-2 text-[11px]">
                      <div className={`mt-0.5 w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                        change.riskScore > 0.8 ? 'bg-red-500 animate-pulse' : change.riskScore > 0.5 ? 'bg-amber-500' : 'bg-zinc-500'
                      }`} />
                      <div className="min-w-0">
                        <span className="font-[var(--font-mono)] text-zinc-300 font-semibold">{change.file}</span>
                        <span className="text-zinc-600 ml-1">:{change.lines}</span>
                        <span className={`ml-1.5 text-[9px] px-1.5 py-0.5 rounded font-semibold ${
                          change.type === 'Design' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}>{change.type}</span>
                        <p className="text-zinc-500 mt-0.5 leading-relaxed">{change.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>

          {/* ──── PRIORITIZED FAILURE LIST ──── */}
          <Card className="mb-6" delay={550}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Crosshair size={15} className="text-red-400" /> Prioritized Failure List
              </h3>
              <div className="text-[10px] text-zinc-500 font-medium flex items-center gap-1.5 bg-zinc-800/50 px-3 py-1.5 rounded-lg border border-zinc-700/50">
                <Info size={11} />
                Priority = 40% severity + 35% impact + 25% change correlation
              </div>
            </div>

            <div className="overflow-auto border border-zinc-800/60 rounded-xl bg-zinc-950/80">
              <table className="w-full text-left text-xs">
                <thead className="bg-zinc-900/90 text-zinc-500 sticky top-0 z-10 backdrop-blur-md border-b border-zinc-800/80">
                  <tr>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider w-16">Priority</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Failure ID</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Signature</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Category</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider">Severity</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider text-center">Recurrences</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider text-right">Tests Hit</th>
                    <th className="px-4 py-3 font-semibold text-[10px] uppercase tracking-wider text-right">Score</th>
                    <th className="px-4 py-3 w-8"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/30">
                  {prioritizedFailures.map((failure, idx) => {
                    const catInfo = ERROR_CATEGORIES.find(c => c.id === failure.category);
                    const sevStyle = SEVERITY_COLORS[failure.severity];
                    const isExpanded = expandedFailure === failure.id;
                    
                    return (
                      <React.Fragment key={failure.id}>
                        <tr
                          className="table-row-interactive cursor-pointer group"
                          onClick={() => setExpandedFailure(isExpanded ? null : failure.id)}
                        >
                          <td className="px-4 py-2.5">
                            <div className="flex items-center gap-1.5">
                              {idx === 0 && <Flame size={12} className="text-red-500" />}
                              <span className={`font-[var(--font-mono)] font-bold text-xs ${
                                idx === 0 ? 'text-red-400' : idx < 3 ? 'text-amber-400' : 'text-zinc-400'
                              }`}>P{idx + 1}</span>
                            </div>
                          </td>
                          <td className="px-4 py-2.5">
                            <div className="flex items-center gap-2">
                              <span className={`w-1.5 h-1.5 rounded-full ${sevStyle.dot} ${failure.severity === 'critical' ? 'animate-pulse' : ''}`} />
                              <span className="font-[var(--font-mono)] text-zinc-300 text-[11px] font-semibold">{failure.id}</span>
                            </div>
                          </td>
                          <td className="px-4 py-2.5">
                            <span className="font-[var(--font-mono)] text-[9px] text-purple-300/70 bg-purple-500/5 border border-purple-500/15 px-1.5 py-0.5 rounded">{failure.signature}</span>
                          </td>
                          <td className="px-4 py-2.5">
                            <span className={`chip-status ${catInfo?.bgClass || ''}`}>
                              {catInfo?.label || failure.category}
                            </span>
                          </td>
                          <td className="px-4 py-2.5">
                            <span className={`chip-status ${sevStyle.bg} ${sevStyle.text} border ${sevStyle.border}`}>
                              <span className={`w-1 h-1 rounded-full ${sevStyle.dot}`} />
                              {failure.severity}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <span className={`font-[var(--font-mono)] font-bold text-[11px] ${
                              failure.recurrences > 6 ? 'text-red-400' : failure.recurrences > 3 ? 'text-amber-400' : 'text-zinc-300'
                            }`}>
                              {failure.recurrences}×
                            </span>
                            {failure.recurrences === 1 && <Sparkles size={9} className="inline ml-1 text-emerald-400" />}
                          </td>
                          <td className="px-4 py-2.5 text-right">
                            <span className="font-[var(--font-mono)] font-bold text-zinc-200 text-[11px]">{failure.affectedTests}</span>
                          </td>
                          <td className="px-4 py-2.5 text-right">
                            <span className={`font-[var(--font-mono)] font-extrabold text-xs ${
                              failure.debugPriority > 80 ? 'text-red-400' :
                              failure.debugPriority > 50 ? 'text-amber-400' : 'text-zinc-300'
                            }`}>{failure.debugPriority.toFixed(1)}</span>
                          </td>
                          <td className="px-4 py-2.5">
                            <ChevronDown size={12} className={`text-zinc-600 transition-transform duration-200 ${isExpanded ? 'rotate-180 text-zinc-400' : ''} group-hover:text-zinc-400`} />
                          </td>
                        </tr>
                        {/* Expanded detail */}
                        {isExpanded && (
                          <tr className="animate-fade-in">
                            <td colSpan={10} className="px-4 py-0">
                              <div className="py-3 px-4 mb-2 mt-1 bg-zinc-900/60 border border-zinc-800/60 rounded-lg space-y-2">
                                <div>
                                  <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider mb-1">Error Message</p>
                                  <p className="text-xs text-zinc-200 leading-relaxed">{failure.message}</p>
                                </div>
                                {/* Signature & Recurrence Detail */}
                                <div className="flex flex-wrap gap-4 pt-2 border-t border-zinc-800/40">
                                  <div className="flex items-start gap-2">
                                    <Fingerprint size={12} className="text-purple-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                      <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider mb-0.5">Signature</p>
                                      <p className="text-xs font-[var(--font-mono)] text-purple-300">{failure.signature}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-start gap-2">
                                    <Repeat size={12} className="text-amber-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                      <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider mb-0.5">Recurrence History</p>
                                      <p className="text-xs text-zinc-300">
                                        <span className="font-[var(--font-mono)] font-bold text-amber-400">{failure.recurrences}× seen</span>
                                        <span className="text-zinc-600 mx-1.5">|</span>
                                        First: <span className="font-[var(--font-mono)] text-zinc-400">{failure.firstSeen}</span>
                                        <span className="text-zinc-600 mx-1.5">→</span>
                                        Latest: <span className="font-[var(--font-mono)] text-zinc-400">{failure.lastSeen}</span>
                                      </p>
                                    </div>
                                  </div>
                                </div>
                                <div className="flex items-start gap-2 pt-2 border-t border-zinc-800/40">
                                  <GitCommit size={12} className="text-zinc-500 mt-0.5 flex-shrink-0" />
                                  <div>
                                    <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider mb-0.5">Related Change</p>
                                    <p className="text-xs font-[var(--font-mono)] text-amber-400">{failure.relatedChange}</p>
                                  </div>
                                </div>
                                <div className="flex items-start gap-2 pt-2 border-t border-zinc-800/40">
                                  <FileWarning size={12} className="text-zinc-500 mt-0.5 flex-shrink-0" />
                                  <div>
                                    <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider mb-0.5">Source Test</p>
                                    <p className="text-xs font-[var(--font-mono)] text-zinc-300">{failure.testId}</p>
                                  </div>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>

          {/* ──── DEBUG STARTING POINTS ──── */}
          <Card delay={600}>
            <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
              <Lightbulb size={15} className="text-amber-400" /> Suggested Debug Starting Points
            </h3>
            <p className="text-[10px] text-zinc-500 mb-4">Files ranked by composite failure correlation. Start your debug session here for maximum efficiency.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {debugSuggestions.map((sug, idx) => (
                <div
                  key={sug.file}
                  className={`relative p-4 rounded-xl border transition-all duration-300 hover:scale-[1.02] ${
                    idx === 0
                      ? 'bg-red-500/5 border-red-500/20 hover:border-red-500/40 shadow-[0_0_20px_rgba(239,68,68,0.05)]'
                      : 'bg-zinc-900/60 border-zinc-800/60 hover:border-zinc-700'
                  }`}
                >
                  {idx === 0 && (
                    <div className="absolute top-3 right-3 text-[9px] font-bold uppercase tracking-wider bg-red-500/15 text-red-400 border border-red-500/25 px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Flame size={9} /> Top Priority
                    </div>
                  )}

                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-1.5 rounded-lg ${
                      idx === 0 ? 'bg-red-500/10' : 'bg-zinc-800'
                    }`}>
                      <FolderSearch size={14} className={idx === 0 ? 'text-red-400' : 'text-zinc-400'} />
                    </div>
                    <div>
                      <p className="text-xs font-bold font-[var(--font-mono)] text-white">{sug.file}</p>
                      <p className="text-[10px] text-zinc-500">{sug.failures.length} linked failure{sug.failures.length > 1 ? 's' : ''}</p>
                    </div>
                  </div>

                  <div className="space-y-1.5 mb-3">
                    {sug.reasons.slice(0, 2).map((reason, i) => (
                      <div key={i} className="flex items-start gap-1.5 text-[10px] text-zinc-400">
                        <ArrowRight size={9} className="text-zinc-600 mt-0.5 flex-shrink-0" />
                        <span>{reason}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-zinc-800/50">
                    <span className="text-[10px] text-zinc-500 font-medium">Debug Priority</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-zinc-950 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="h-full rounded-full animate-bar-grow"
                          style={{
                            width: `${sug.maxPriority}%`,
                            background: sug.maxPriority > 80 ? '#ef4444' : sug.maxPriority > 50 ? '#f59e0b' : '#71717a',
                            animationDelay: `${0.5 + idx * 0.15}s`,
                          }}
                        />
                      </div>
                      <span className={`text-[10px] font-[var(--font-mono)] font-extrabold ${
                        sug.maxPriority > 80 ? 'text-red-400' : sug.maxPriority > 50 ? 'text-amber-400' : 'text-zinc-400'
                      }`}>{sug.maxPriority.toFixed(0)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Efficiency Summary */}
            <div className="mt-5 p-4 bg-emerald-500/5 border border-emerald-500/15 rounded-xl flex items-center gap-3">
              <div className="p-2 bg-emerald-500/10 rounded-lg">
                <Zap size={16} className="text-emerald-400" />
              </div>
              <div>
                <p className="text-xs font-bold text-emerald-400">Estimated Debug Effort Reduction</p>
                <p className="text-[10px] text-zinc-400 mt-0.5">
                  By starting with the top {Math.min(3, debugSuggestions.length)} files, you cover <span className="text-white font-bold font-[var(--font-mono)]">{prioritizedFailures.filter(f => f.debugPriority > 50).length}/{prioritizedFailures.length}</span> high-priority failures.
                  Estimated <span className="text-emerald-400 font-bold font-[var(--font-mono)]">{Math.round(70 + (prioritizedFailures.length > 4 ? 8 : 0))}%</span> reduction in triage time vs. sequential debug.
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Footer */}
        <footer className="mt-8 pb-4 text-center text-[10px] text-zinc-700 font-medium relative z-10">
          SanDisk Optima v2.0 — CoreOptima AI Engine — Confidential & Proprietary
        </footer>
      </main>
    </div>
  );
}
